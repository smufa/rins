# commands

- roslaunch exercise3 rins_world.launch
- roslaunch turtlebot_rviz_launchers view_robot.launch
- roslaunch turtlebot_teleop keyboard_teleop.launch
- roslaunch exercise3 amcl_simulation.launch
- roslaunch turtlebot_rviz_launchers view_navigation.launch
